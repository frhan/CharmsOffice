#!/bin/sh
cd jni
ndk-build