#!/bin/sh
javah -classpath bin -d jni com.uraroji.garage.android.lame.SimpleLame
