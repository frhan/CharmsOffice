package com.charmsoffice.mobilestudio.util;

public class AssignmentList {
	private String assignmentName;
	private String assignmentDate;
	private String assignmentAccomp;
	private String assignmentMessage;
	private String recordingListScore;
	private String recordingListMessage;

	public String getRecordingListScore() {
		return recordingListScore;
	}

	public void setRecordingListScore(String recordingListScore) {
		this.recordingListScore = recordingListScore;
	}

	public String getRecordingListMessage() {
		return recordingListMessage;
	}

	public void setRecordingListMessage(String recordingListMessage) {
		this.recordingListMessage = recordingListMessage;
	}

	public String getAssignmentMessage() {
		return assignmentMessage;
	}

	public void setAssignmentMessage(String assignmentMessage) {
		this.assignmentMessage = assignmentMessage;
	}

	public String getAssignmentAccomp() {
		return assignmentAccomp;
	}

	public void setAssignmentAccomp(String assignmentAccomp) {
		this.assignmentAccomp = assignmentAccomp;
	}

	public void setAssignmentName(String assignmentName) {
		this.assignmentName = assignmentName;
	}

	public String getAssignmentName() {
		return assignmentName;
	}

	public void setAssignmentDate(String assignmentDate) {
		this.assignmentDate = assignmentDate;
	}

	public String getAssignmentDate() {
		return assignmentDate;
	}

}
