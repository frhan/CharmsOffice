package com.charmsoffice.mobilestudio.data;

public interface MicrophoneInputListener {
	
	public void processAudioFrame(short[] audioFrame);

}
